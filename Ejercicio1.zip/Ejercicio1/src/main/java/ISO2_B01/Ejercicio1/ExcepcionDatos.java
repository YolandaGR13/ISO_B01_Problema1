package ISO2_B01.Ejercicio1;

import java.util.*;

public class ExcepcionDatos extends Exception{
	
	public ExcepcionDatos(Date msj) {
	}
}
